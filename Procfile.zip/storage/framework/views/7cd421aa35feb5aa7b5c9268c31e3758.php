

<?php $__env->startSection('content'); ?>
    <div style="display: flex; justify-content: center; margin-bottom: 20px;">
        <h1 style="text-align: center;">Blog posts</h1>
    </div>

    <?php if(auth()->guard()->check()): ?>
        <div style="display: flex; justify-content: center; gap: 20px; margin-bottom: 20px;">
            <h4>
                <a href="<?php echo e(route('posts.index', ['filter' => 'all'])); ?>" class="<?php echo e($filter === 'all' ? 'active underline' : ''); ?>">All Posts</a>
            </h4>
            <h4>
                <a href="<?php echo e(route('posts.index', ['filter' => 'active'])); ?>" class="<?php echo e($filter === 'active' ? 'active underline' : ''); ?>">Active Posts</a>
            </h4>
            <h4>
                <a href="<?php echo e(route('posts.index', ['filter' => 'inactive'])); ?>" class="<?php echo e($filter === 'inactive' ? 'active underline' : ''); ?>">Inactive Posts</a>
            </h4>
        </div>
    <?php endif; ?>

    <?php if($posts->count()): ?>
        <div class="posts-grid"> 
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                <?php if(auth()->check() || $post->status === 1): ?>
                    <article style="padding: 10px 0; display: flex; flex-direction: column; align-items: center; justify-content: center;"> 
                        <?php if($post->image_path): ?>
                            <a href="<?php echo e(route('posts.show', $post)); ?>">
                                <img src="<?php echo e(Storage::url($post->image_path)); ?>" alt="<?php echo e($post->title); ?> Image" style="width: 100%; height: auto; object-fit: contain;">
                            </a>
                        <?php endif; ?>
                        <h2 style="text-align: start;">
                            <a href="<?php echo e(route('posts.show', $post)); ?>"><?php echo e($post->title); ?></a>
                        </h2>
                        <p style="text-align: start;"><?php echo e($post->publication_date->format('F j, Y')); ?></p>
                    </article>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div> 
    <?php else: ?>
        <p style="text-align: center; display: flex; justify-content: center;">No posts found.</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hstro\Documents\GitHub\mans-blogs\resources\views\posts\index.blade.php ENDPATH**/ ?>