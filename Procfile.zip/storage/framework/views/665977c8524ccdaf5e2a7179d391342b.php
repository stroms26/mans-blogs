

<?php $__env->startSection('content'); ?>
    <h1 style="text-align: center;">Edit Post</h1>

    <div style="width: 70%; margin: 0 auto;">
        <form action="<?php echo e(route('posts.update', $post)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>

            <div class="form-group" style="margin-bottom: 20px;">
                <label for="title" style="display: block;">Title</label>
                <input type="text" name="title" id="title" class="form-control" value="<?php echo e(old('title', $post->title)); ?>" required>
                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group" style="margin-bottom: 20px;">
                <label for="body" style="display: block;">Body</label>
                <textarea name="body" id="body" class="form-control" rows="5" required><?php echo e(old('body', $post->body)); ?></textarea>
                <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group" style="margin-bottom: 20px;">
                <label for="image" style="display: block;">Image</label>
                <?php if($post->image_path): ?>
                    <img src="<?php echo e(Storage::url($post->image_path)); ?>" alt="<?php echo e($post->title); ?> Image" style="width: 100%; height: auto; object-fit: contain;">
                <?php endif; ?>
                <input type="file" name="image" id="image" class="form-control-file">
                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group" style="margin-bottom: 20px;">
                <label for="publication_date" style="display: block;">Publication Date</label>
                <input type="date" name="publication_date" id="publication_date" class="form-control" value="<?php echo e(old('publication_date', $post->publication_date->format('Y-m-d'))); ?>" required>
                <?php $__errorArgs = ['publication_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group" style="margin-bottom: 20px;">
                <label for="status" style="display: block;">Status</label>
                <select name="status" id="status" class="form-control" required>
                    <option value="1" <?php echo e(old('status', $post->status) == 1 ? 'selected' : ''); ?>>Active</option>
                    <option value="0" <?php echo e(old('status', $post->status) == 0 ? 'selected' : ''); ?>>Inactive</option>
                </select>
                <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                    <div class="error"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <button type="submit" class="btn btn-primary">Update Post</button>
        </form>

        <form action="<?php echo e(route('posts.destroy', $post)); ?>" method="POST" style="margin-top: 20px;">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-danger">Delete Post</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hstro\Documents\GitHub\mans-blogs\resources\views\posts\edit.blade.php ENDPATH**/ ?>