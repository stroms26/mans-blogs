

<?php $__env->startSection('content'); ?>
    <h1 style="text-align: center;">Create New Post</h1>

    <div style="width: 70%; margin: 0 auto;">
        <form action="<?php echo e(route('posts.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <div class="form-group" style="margin-bottom: 20px;">
                <label for="title" style="display: block;">Title</label>
                <input type="text" name="title" id="title" class="form-control" value="<?php echo e(old('title')); ?>" required>
            </div>

            <div class="form-group" style="margin-bottom: 20px;">
                <label for="body" style="display: block;">Body</label>
                <textarea name="body" id="body" class="form-control" rows="5" required><?php echo e(old('body')); ?></textarea>
            </div>

            <div class="form-group" style="margin-bottom: 20px;">
                <label for="image">Upload Image</label>
                <input type="file" name="image" id="image" class="form-control-file">
            </div>

            <div class="form-group" style="margin-bottom: 20px;">
                <label for="publication_date">Publication Date</label>
                <input type="date" name="publication_date" id="publication_date" class="form-control" value="<?php echo e(old('publication_date')); ?>" required>
            </div>

            <div class="form-group" style="margin-bottom: 20px;">
                <label for="status">Status</label>
                <select name="status" id="status" class="form-control" required>
                    <option value="1">Active</option>
                    <option value="0">Inactive</option>
                </select>
            </div>

            <button type="submit" class="btn btn-primary">Create Post</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hstro\Documents\GitHub\mans-blogs\resources\views\posts\create.blade.php ENDPATH**/ ?>