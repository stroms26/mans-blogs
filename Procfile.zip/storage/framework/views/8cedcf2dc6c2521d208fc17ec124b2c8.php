

<?php $__env->startSection('content'); ?>
    <style>
        .content {
            width: 50%;
            margin: 30px auto;
            display: flex;
            gap: 20px;
        }

        .content img {
            max-width: 50%;
            height: auto;
            object-fit: cover;
        }

        .content .details {
            flex: 1;
        }

        .content h1 {
            text-align: left;
            width: 100%;
        }

        .btn-custom {
            font-size: 15px;
            font-weight: 400;
            color: grey;
            text-decoration: none;
            background: none;
            border: none;
            cursor: pointer;
        }

        .btn-custom:hover,
        .btn-custom:focus {
            text-decoration: underline;
            color: black;
        }

        .btn-custom:focus {
            outline: none;
        }
    </style>

    <div class="content">
        <?php if($post->image_path): ?>
            <img src="<?php echo e(Storage::url($post->image_path)); ?>" alt="<?php echo e($post->title); ?> Image">
        <?php endif; ?>

        <div class="details">
            <h1><?php echo e($post->title); ?></h1>
            <p><?php echo e($post->body); ?></p>
            <p>Published on: <?php echo e($post->publication_date->format('F j, Y')); ?></p> 
            <p>Status: <?php echo e($post->status ? 'Active' : 'Inactive'); ?></p>

            <div style="margin-top: 20px;">
                <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(route('posts.edit', $post)); ?>" class="btn-custom">Edit Post</a>

                    <form action="<?php echo e(route('posts.destroy', $post)); ?>" method="POST" style="display: inline;" onsubmit="return confirmDelete()"> 
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn-custom btn-custom-danger">Delete post</button>
                    </form>
                <?php endif; ?>

                <a href="<?php echo e(route('posts.index')); ?>" class="btn-custom">Back to Posts</a>
            </div>
        </div>
    </div>

    <script>
        function confirmDelete() {
            return confirm("Do you want to delete this post?");
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hstro\Documents\GitHub\mans-blogs\resources\views\posts\show.blade.php ENDPATH**/ ?>